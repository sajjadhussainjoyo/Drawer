import 'dart:js';

import 'package:chess/about.dart';
import 'package:chess/chat.dart';
import 'package:chess/home.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Home(),
    );
  }
}

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'WhatsApp',
          style: TextStyle(),
        ),
        backgroundColor: Colors.green,
      ),
      body: ListView(
        children: <Widget>[
          ListTile(
            //tileColor: Colors.orange,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const HomeView()),
              );
            },
            leading: CircleAvatar(
              backgroundImage: NetworkImage(
                  'https://cdn.pixabay.com/photo/2016/03/31/20/11/avatar-1295575_1280.png'),
            ),
            title: Text('Hello........'),
            subtitle: Text('Its me I was wondering'),
            trailing: Icon(Icons.call),
          ),
          ListTile(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ChatView()),
              );
            },
            title: Text('John Wick'),
            subtitle: Text('If you steal my dog I will kill you'),
            trailing: Icon(Icons.call),
            leading: CircleAvatar(
              backgroundImage: AssetImage('assets/images/john.jpg'),
            ),
          ),
          ListTile(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AboutView()),
              );
            },
            title: Text('Babu Roa Ganpat'),
            subtitle:
                Text('Machli? Woh tou main mast teel mai fry karka kha gaya'),
            trailing: Icon(Icons.call),
            leading: CircleAvatar(
              backgroundImage: NetworkImage(
                  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRyOgMCkYF3PjZTAw5QespXCn9E80aB9qpBw&s'),
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          child: const Column(
            children: const <Widget>[
              // DrawerHeader (

              //   child: Text('Header'),
              //   decoration: BoxDecoration(color: Colors.orange),

              // ),

              UserAccountsDrawerHeader(
                currentAccountPicture: CircleAvatar(
                  backgroundImage: NetworkImage(
                      'https://pilbox.themuse.com/image.jpg?filter=antialias&h=693&opt=1&pos=top-left&prog=1&q=keep&url=https%3A%2F%2Fcms-assets.themuse.com%2Fmedia%2Flead%2F546.jpg&w=700'),
                ),
                accountName: Text('Sajjad'),
                accountEmail: Text('sajjadhussain613@gmail.com'),
              ),
              ListTile(
                title: Text('Search'),
                leading: Icon(Icons.search),
              ),
              ListTile(
                title: Text('Home'),
                leading: Icon(Icons.home),
              ),
              ListTile(
                title: Text('Settings'),
                leading: Icon(Icons.notifications),
              ),
              ListTile(
                title: Text('Notifications'),
                leading: Icon(Icons.notifications),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
