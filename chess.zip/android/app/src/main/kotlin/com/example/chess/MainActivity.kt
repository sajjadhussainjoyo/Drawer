package com.example.chess

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
